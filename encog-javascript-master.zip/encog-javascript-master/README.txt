Encog for Javascript 1.0

The following links will be helpful getting started with Encog for Javascript.

Getting Started:

http://www.codeproject.com/Articles/477689/JavaScript-Machine-Learning-and-Neural-Networks-wi

Important Links:

http://www.heatonresearch.com/encog
http://www.heatonresearch.com/wiki